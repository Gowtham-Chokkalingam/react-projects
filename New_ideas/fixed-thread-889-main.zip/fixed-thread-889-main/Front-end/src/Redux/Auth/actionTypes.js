export const auth_signIn_success = 'auth/signin/success';
export const auth_signIn_error = 'auth/signin/error';
export const auth_signIn_loading = 'auth/signin/loading';
export const auth_signUp_success = 'auth/signup/success';
export const auth_signUp_error = 'auth/signup/error';
export const auth_signUp_loading = 'auth/signup/loading';
export const auth_signOut = 'auth/signupout';
