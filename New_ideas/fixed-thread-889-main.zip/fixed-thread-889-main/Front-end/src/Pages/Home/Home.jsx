import { Cart } from "../../Components/Cart/cart"
export const Home = () => {
    return <div>
        {/* Home */}
        <Cart></Cart>
    </div>
}